/**
 */
package views;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Column</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link views.Column#getHeader <em>Header</em>}</li>
 *   <li>{@link views.Column#getPropertyRef <em>Property Ref</em>}</li>
 * </ul>
 *
 * @see views.ViewsPackage#getColumn()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='isPropertyMemberOfClass'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot isPropertyMemberOfClass='\n\t\t(self -> closure(oclContainer()) -> select(oclIsTypeOf(TableViewElement))).oclAsType(TableViewElement)\n\t\t -> forAll((classRef->closure(superclass)).properties->includes(self.propertyRef))'"
 * @generated
 */
public interface Column extends EObject {
	/**
	 * Returns the value of the '<em><b>Header</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Header</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Header</em>' attribute.
	 * @see #setHeader(String)
	 * @see views.ViewsPackage#getColumn_Header()
	 * @model required="true"
	 * @generated
	 */
	String getHeader();

	/**
	 * Sets the value of the '{@link views.Column#getHeader <em>Header</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Header</em>' attribute.
	 * @see #getHeader()
	 * @generated
	 */
	void setHeader(String value);

	/**
	 * Returns the value of the '<em><b>Property Ref</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Property Ref</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Property Ref</em>' reference.
	 * @see #setPropertyRef(Property)
	 * @see views.ViewsPackage#getColumn_PropertyRef()
	 * @model
	 * @generated
	 */
	Property getPropertyRef();

	/**
	 * Sets the value of the '{@link views.Column#getPropertyRef <em>Property Ref</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Property Ref</em>' reference.
	 * @see #getPropertyRef()
	 * @generated
	 */
	void setPropertyRef(Property value);

} // Column
